<?php

return [
    'smtpUsername' => 'hi.aifarm@gmail.com',
    'smtpPassword' => 'jaqixxhpajdfgsug',
    'telegramBotToken' => '5900211920:AAEBl9hbHR2_L3c_p2A01H3vWI9CbGZbY2k',
    'aesKey' => '41f4rml4r15m4n15',
];